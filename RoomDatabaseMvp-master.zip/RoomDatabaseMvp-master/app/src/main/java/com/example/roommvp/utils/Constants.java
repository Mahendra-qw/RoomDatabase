package com.example.roommvp.utils;

public class Constants {

    public static final int FIELD_NAME = 10;
    public static final int FIELD_ADDRESS = 11;
    public static final int FIELD_PHONE = 12;
    public static final int FIELD_EMAIL = 13;

    public static final String PERSON_ID = "person_id";
}
